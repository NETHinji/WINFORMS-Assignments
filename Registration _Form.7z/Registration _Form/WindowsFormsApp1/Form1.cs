﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void imgcal_Click(object sender, EventArgs e)
        {
            
             OpenFileDialog open = new OpenFileDialog();
            
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                imgcal.Image = new Bitmap(open.FileName);
            }




                CalendarDialog cal = new CalendarDialog();
            cal.StartPosition = FormStartPosition.CenterScreen;
            if (cal.ShowDialog() == DialogResult.OK)
                txtbirthdate.Text = cal.DateSelection.SelectionStart.
                ToString("dd-MMM-yyyy");


            
        }
    }
}
